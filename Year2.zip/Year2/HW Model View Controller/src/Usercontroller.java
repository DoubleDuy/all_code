import java.util.Scanner;

public class Usercontroller extends Usermodel {
    private Usermodel model;
    private Userview view;

    public Usercontroller(Usermodel model, Userview view) {
        this.model = model;
        this.view = view;
        String username;
        String password;
    }

    public void login(String username, String password) {
        Scanner scanner = new Scanner(System.in);
        boolean user=authenticate(username, password);

        while (!user) {
            if (user!=authenticate(username, password)) {
                view.showMessage("Username or Password is invalid");
                System.out.print("Enter username: ");
                username = scanner.nextLine();
                System.out.print("Enter password: ");
                password = scanner.nextLine();
            }else{
            view.showMessage("Welcome to my world");
            }
        }
    }
    public void addNewUser(String username, String password) {
        if (model.userExists(username)) {
            view.showMessage("This user exists in the array");
        } else {
            model.addNewUser(username, password);
            view.showMessage("Add new user successful");
        }
    }

    public void removeUser(String username) {
        if (model.userExists(username)) {
            model.removeUser(username);
            view.showMessage("User already removed");
        } else {
            view.showMessage("This user does not exist");
        }

    }

}

