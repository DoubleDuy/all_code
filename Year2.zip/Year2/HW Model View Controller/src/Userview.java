public class Userview {
    public void showMessage(String msg) {
        System.out.println(msg);
    }
}