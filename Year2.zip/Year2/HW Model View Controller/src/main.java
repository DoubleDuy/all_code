import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        Usermodel model = new Usermodel();
        Userview view = new Userview();
        Usercontroller controller = new Usercontroller(model, view);
        Scanner scanner = new Scanner(System.in);
    
        // Add a new user
        System.out.print("Enter username to add: ");
        String username = scanner.nextLine();
        System.out.print("Enter password to add: ");
        String password = scanner.nextLine();
        controller.addNewUser(username, password);
    
        // Login
        System.out.print("Enter username to login: ");
        username = scanner.nextLine();
        System.out.print("Enter password to login: ");
        password = scanner.nextLine();
        controller.login(username, password);
    
        // Remove a user
        System.out.print("Enter username to remove: ");
        username = scanner.nextLine();
        controller.removeUser(username);

        scanner.close();
    }
}