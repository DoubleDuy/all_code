import java.util.HashMap;
import java.util.Map;

public class Usermodel {
    private Map<String, String> users = new HashMap<>();

    public boolean authenticate(String username, String password) {
        return users.containsKey(username) && users.get(username).equals(password);
    }

    public void addNewUser(String username, String password) {
        users.put(username, password);
    }

    public void removeUser(String username) {
        users.remove(username);
    }

    public boolean userExists(String username) {
        return users.containsKey(username);
    }
}


