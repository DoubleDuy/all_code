public class App {
    public static void main(String[] args) throws Exception {
        MovablePoint Point = new MovablePoint(5, 7, 10, 20);
        System.out.println(Point.toString());
    }
}
