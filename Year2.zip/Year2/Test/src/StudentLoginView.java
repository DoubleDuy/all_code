public class StudentLoginView {
    public void showCurrentUser(String[] currentUser) {
        if (currentUser != null) {
            System.out.println("นักศึกษาปัจจุบัน: " + currentUser[0]);
            System.out.println("สาขาวิชา: " + currentUser[1]);
        } else {
            System.out.println("ไม่มีนักศึกษาปัจจุบัน");
        }
    }
}
