import java.util.Scanner;

public class main {
    public static void main(String[] args) {
        StudentModel model = new StudentModel();
        StudentLoginView view = new StudentLoginView();
        StudentController controller = new StudentController(model, view);

        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        System.out.println("------------- Information -------------");

        while (!exit) {
            System.out.println("1. Log In");
            System.out.println("2. Log Out");
            System.out.print("--> ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    System.out.print("Student ID : ");
                    String id = scanner.nextLine();
                    System.out.print("Password : ");
                    String password = scanner.nextLine();

                    String[] currentUser = controller.login(id, password);
                    if (currentUser != null) {
                        System.out.println("Log In Success");
                        controller.updateView(currentUser);
                    } else {
                        System.out.println("Information is Invalid");
                    }
                    break;

                case 2:
                    System.out.println("Log Out");
                    exit = true;
                    break;

                default:
                    System.out.println("Please Select The Choice Again");
            }
        }

        scanner.close();
    }
}
