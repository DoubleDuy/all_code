public class StudentModel {
    private String[][] student = {
        {"6104800066", "17022000", "นายรักเรียน ขยันยิ่ง", "วิทยาการคอมพิวเตอร์"},
        {"6103400077", "13041999", "นางสาวสวย รักงาม", "พยาบาล"},
        {"6104200088", "20121998", "นายอดตาย สุดหล่อ", "วิศวกรรมไฟฟ้า"}
    };
    private String[] currentUser = new String[2];

    public String[][] getStudent() {
        return student;
    }

    public void setStudent(String[][] student) {
        this.student = student;
    }

    public String[] search(String id) {
        for (String[] s : student) {
            if (s[0].equals(id)) {
                return s;
            }
        }
        return null; // Not found
    }

    public String[] login(String id, String password) {
        for (String[] s : student) {
            if (s[0].equals(id) && s[1].equals(password)) {
                currentUser = new String[]{s[2], s[3]};
                return currentUser;
            }
        }
        return null; // Login failed
    }
}
