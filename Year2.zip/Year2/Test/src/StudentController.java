public class StudentController {
    private StudentModel model;
    private StudentLoginView view;

    public StudentController(StudentModel model, StudentLoginView view) {
        this.model = model;
        this.view = view;
    }

    public String[][] getStudent() {
        return model.getStudent();
    }

    public void setStudent(String[][] student) {
        model.setStudent(student);
    }

    public String[] search(String id) {
        return model.search(id);
    }

    public String[] login(String id, String password) {
        return model.login(id, password);
    }

    public void updateView(String[] currentUser) {
        view.showCurrentUser(currentUser);
    }
}
