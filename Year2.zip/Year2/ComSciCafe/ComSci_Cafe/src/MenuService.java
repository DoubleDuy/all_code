
public interface MenuService {

    Menu getMenuById(String menuID);

}
