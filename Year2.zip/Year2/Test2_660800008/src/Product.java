public class Product {
    private String id;
    private String name;
    private float unipice;

    Product(String id, String name, float unipice) {
        this.id = id;
        this.name = name;
        this.unipice = unipice;
    }

    public String getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getUniprice() {
        return String.valueOf(unipice);
    }

    public void setUniprice() {
        this.unipice = 0.0f;
    }

    public String toString() {
        return "Product [id=" +id+"name="+name+"unitprice="+unipice+ "]";
    }
}
