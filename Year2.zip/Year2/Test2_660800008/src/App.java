public class App {
    public static void main(String[] args) throws Exception {
        Customer obj1 = new Customer("6604800008", "Arpatsra", 5);
        Product obj2 = new Product("001", "Lay", 30);
        Invoice obj3 = new Invoice(null, obj1, 0);

        System.out.println(obj1.toString());
        System.out.println(obj2.toString());
        System.out.println(obj3.toString());
    }
}
