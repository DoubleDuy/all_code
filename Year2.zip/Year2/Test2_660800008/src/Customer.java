public class Customer {
    private String id;
    private String name;
    private int discount;
    private String address;

    Customer(String id, String name, int discount) {
        this.id = id;
        this.name = name;
        this.discount = discount;
    }

    public String getID() {
        return id;
    }

    public String getName() {
        return name;
    }

    public String getDiscount() {
        return String.valueOf(discount);
    }

    public void setDiscount(int discount) {
        this.discount = discount;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String toString() {
        return "Customer [id=" + id + ", name=" + name + ", discount=" + discount + "]";
    }
}