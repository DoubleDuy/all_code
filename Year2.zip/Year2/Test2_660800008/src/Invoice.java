public class  Invoice extends Product {
    private String id;
    private Customer customer;
    private Product product;
    private double amount;

    Invoice(String id, Customer customer, double amount) {
        super(id, id, 0);
        this.customer = customer;
        this.amount = amount;
    }

    public String getID() {
        return id;
    }

    public Customer getCustomer() {
        return customer;
    }

    public void setCustomer(Customer customer) {
        this.customer = customer;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getProductID() {
        return product.getID();
    }

    public String getProductName() {
        return product.getName();
    }

    public String getUnitPrice() {
        return String.valueOf(product.getUniprice());
    }

    public String getCustomerID() {
        return customer.getID();
    }

    public String getCustomerName() {
        return customer.getName();
    }

    public String getCustomerAddress() {
        return customer.getAddress();
    }

    public String getCustomerDiscount() {
        return customer.getDiscount();
    }

    public String getAmountAferDiscount() {
        return String.valueOf(amount - (amount * Double.parseDouble(customer.getDiscount()) / 100));
    }

    public String toString() {
        return customer.toString()+"\t"+product.toString()+"\t"+"netprice="+getAmountAferDiscount();
    }
}
