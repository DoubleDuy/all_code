public class App {
    public static void main(String[] args) throws Exception {
        
        circle obj = new circle();

        System.out.println("Area is " + obj.getArea());
        System.out.println("Cirumference "+ obj.getCircumference());
        System.out.println(obj.toString());
    }
}
