public class main {
    public static void main(String[] args) throws Exception {
        DataModel model = new DataModel();
        DataView view = new DataView();
        DataController controller = new DataController(model, view);

        //เพิ่มข้อมูลลง list
        controller.appendData("6604800008");
        controller.appendData("DoubleDuy");
        controller.appendData("ddoubleduy@gmail.com");

        //บันทึกข้อมูลจาก text file
        controller.saveData("Student.txt");
        //อ่านข้อมูลจาก text file
        controller.loadData("Student.txt");
        controller.showData();
    }
}
