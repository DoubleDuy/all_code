import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.ArrayList;

public class DataModel {
    private List<String> data = new ArrayList<>();

    public List<String> getData() {
        return data;
    }

    public void loadData(String filename) {
        data.clear();
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            while ((line = reader.readLine()) != null) {
                data.add(line);
            }
        }

        catch (IOException ex) {
            ex.printStackTrace();
        }
    }

    //เมธอดบันทึกข้อมูลลง text file
    public void saveData(String filename) throws IOException {
        try(BufferedWriter writer=new BufferedWriter(new FileWriter(filename))){
            for(String line : data){
            writer.write(line);
            writer.newLine();
            }
        }
    }
}

