import java.io.IOException;
import java.util.List;

public class DataController {
    private DataModel model;
    private DataView view;

    public DataController(DataModel model, DataView view) {
        this.model = model;
        this.view = view;
    }

    public void loadData(String filename) {
        try {
            model.loadData(filename);
            view.showMessage("Data Loaded");
        }

        catch (Exception ex) {
            view.showMessage("Error :" + ex.getMessage());
        }
    }

    //เรียกใช้ saveData
    public void saveData(String filename) {
        try {
            model.saveData(filename);
            view.showMessage("Data Saved");
        }

        catch (Exception ex) {
            view.showMessage("Error :" + ex.getMessage());
        }
    }

    //เมธอดแสดงข้อมูลจาก text file
    public void showData() {
        List<String> data = model.getData();
        view.showData(model.getData());
    }

    public void appendData(String newdata) {
        model.getData().add(newdata);
    }
}
