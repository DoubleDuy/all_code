import java.util.List;

public class DataView {
    //เมธอดแสดงข้อมูล
    public void showData(List<String> data) {
        for (String line : data) {
            System.out.println(line);
        }
    }

    //เมธอดแสดงข้อความใดๆ
    public void showMessage(String msg) {
        System.out.println(msg);
    }
}
