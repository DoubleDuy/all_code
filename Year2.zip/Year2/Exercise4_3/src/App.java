public class App {
    public static void main(String[] args) throws Exception {
        Point2D obj = new Point2D(3, 8);
        System.out.println(obj.toString());

        Point2D obj2 = new Point3D(9, 1, 2);
        System.out.println(obj2.toString());
    }
}
