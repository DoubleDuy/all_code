import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

class User {
    protected String id;
    protected String name;
    protected String email;
    protected String password;

    public User(String id, String name, String email, String password) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.password = password;
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public String getEmail() { return email; }
    public String getPassword() { return password; }
}

class Student extends User {
    public Student(String id, String name, String email, String password) {
        super(id, name, email, password);
    }
}

class Professor extends User {
    public Professor(String id, String name, String email, String password) {
        super(id, name, email, password);
    }
}

class Thesis {
    private String id;
    private String title;
    private String academicYear;
    private boolean available;

    public Thesis(String id, String title, String academicYear) {
        this.id = id;
        this.title = title;
        this.academicYear = academicYear;
        this.available = true; // Default to available
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getAcademicYear() { return academicYear; }
    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }
}

class Loan {
    private String id;
    private String studentId;
    private String thesisId;
    private Date loanDate;
    private boolean isConfirmed;

    public Loan(String id, String studentId, String thesisId, Date loanDate) {
        this.id = id;
        this.studentId = studentId;
        this.thesisId = thesisId;
        this.loanDate = loanDate;
        this.isConfirmed = false; // Default to not confirmed
    }

    public void confirmLoan() {
        this.isConfirmed = true;
    }

    public boolean borrowThesis(Professor professor) {
        if (professor != null && isConfirmed) {
            return true; // Successfully borrowed
        } else {
            System.out.println("การยืมปริญญานิพนธ์ไม่สามารถทำได้ เนื่องจากยังไม่ได้รับการยืนยันจากอาจารย์");
            return false; // Failed to borrow
        }
    }

    public String getId() { return id; }
    public String getStudentId() { return studentId; }
    public String getThesisId() { return thesisId; }
    public Date getLoanDate() { return loanDate; }
    public boolean isConfirmed() { return isConfirmed; }
}

public class ThesisManagementApp {
    private List<Student> students = new ArrayList<>();
    private List<Professor> professors = new ArrayList<>();
    private List<Thesis> theses = new ArrayList<>();
    private List<Loan> loans = new ArrayList<>();

    public void addStudent(Student student) {
        students.add(student);
    }

    public void addProfessor(Professor professor) {
        professors.add(professor);
    }

    public void addThesis(Thesis thesis) {
        theses.add(thesis);
    }

    public void addLoan(Loan loan) {
        loans.add(loan);
    }

    public void removeStudent(String studentId) {
        students.removeIf(student -> student.getId().equals(studentId));
    }

    public void removeProfessor(String professorId) {
        professors.removeIf(professor -> professor.getId().equals(professorId));
    }

    public void saveDataToFile() throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter("data.txt"))) {
            writer.write("Students:\n");
            for (Student student : students) {
                writer.write(student.getId() + "," + student.getName() + "," + student.getEmail() + "\n");
            }

            writer.write("Professors:\n");
            for (Professor professor : professors) {
                writer.write(professor.getId() + "," + professor.getName() + "," + professor.getEmail() + "\n");
            }

            writer.write("Theses:\n");
            for (Thesis thesis : theses) {
                writer.write(thesis.getId() + "," + thesis.getTitle() + "," + thesis.getAcademicYear() + "," + thesis.isAvailable() + "\n");
            }

            writer.write("Loans:\n");
            for (Loan loan : loans) {
                writer.write(loan.getId() + "," + loan.getStudentId() + "," + loan.getThesisId() + "," + loan.getLoanDate() + "," + loan.isConfirmed() + "\n");
            }
        }
    }

    public void checkThesisStatus(String thesisId) {
        for (Thesis thesis : theses) {
            if (thesis.getId().equals(thesisId)) {
                System.out.println("Thesis Title: " + thesis.getTitle() + ", Available: " + thesis.isAvailable());
                return;
            }
        }
        System.out.println("Thesis not found.");
    }

    public void allowLoan(Loan loan, Professor professor) {
        if (professor != null) {
            loan.confirmLoan();
            System.out.println("Loan confirmed by Professor: " + professor.getName());
        } else {
            System.out.println("Professor not found.");
        }
    }

    public static void main(String[] args) throws IOException {
        ThesisManagementApp app = new ThesisManagementApp();
        Scanner scanner = new Scanner(System.in);

        // ตัวอย่างการเพิ่มนักศึกษา
        Student student1 = new Student("S001", "John Doe", "john.doe@example.com", "password123");
        app.addStudent(student1);

        // ตัวอย่างการเพิ่มอาจารย์
        Professor professor1 = new Professor("P001", "Dr. Smith", "dr.smith@example.com", "profpassword");
        app.addProfessor(professor1);

        // ตัวอย่างการเพิ่มปริญญานิพนธ์
        Thesis thesis1 = new Thesis("T001", "Thesis Title 1", "2023");
        app.addThesis(thesis1);

        // ตัวอย่างการเพิ่มการยืม
        Loan loan1 = new Loan("L001", student1.getId(), thesis1.getId(), new Date());
        app.addLoan(loan1);

        // ตรวจสอบสถานะของ Thesis
        app.checkThesisStatus(thesis1.getId());

        // อนุญาตการยืม
        app.allowLoan(loan1, professor1);

        // ลองยืมปริญญานิพนธ์
        boolean borrowed = loan1.borrowThesis(professor1);
        System.out.println("Borrowed: " + borrowed);

        // บันทึกข้อมูลลงไฟล์
        app.saveDataToFile();

        scanner.close();
    }
}